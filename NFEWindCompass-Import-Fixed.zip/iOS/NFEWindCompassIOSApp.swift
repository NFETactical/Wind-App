import SwiftUI

@main
struct NFEWindCompassIOSApp: App {
    var body: some Scene {
        WindowGroup {
            CompassView(isWatch: false)
                .preferredColorScheme(.dark)
        }
    }
}
