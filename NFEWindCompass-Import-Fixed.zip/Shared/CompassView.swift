import SwiftUI

struct CompassView: View {
    @StateObject private var model = CompassModel()
    var isWatch: Bool = false

    var body: some View {
        GeometryReader { geo in
            let size = isWatch ? min(geo.size.width * 0.98, geo.size.height * 0.76) : min(geo.size.width * 0.92, geo.size.height * 0.76)
            VStack(spacing: isWatch ? 1 : 8) {
                ZStack {
                    Circle().stroke(.white, lineWidth: isWatch ? 1.5 : 2)
                    Circle().inset(by: size * 0.028).stroke(.white.opacity(0.95), lineWidth: 1)

                    ForEach(0..<36, id: \.self) { i in
                        Capsule().fill(.white)
                            .frame(width: i % 3 == 0 ? (isWatch ? 2 : 2.5) : 1,
                                   height: i % 3 == 0 ? size * 0.055 : size * 0.032)
                            .offset(y: -size * 0.425)
                            .rotationEffect(.degrees(Double(i * 10) - model.heading))
                    }

                    ForEach(Array(zip(["N", "E", "S", "W"], [0.0, 90.0, 180.0, 270.0])), id: \.0) { letter, angle in
                        Text(letter)
                            .font(.system(size: size * (isWatch ? 0.075 : 0.065), weight: .black, design: .rounded))
                            .foregroundStyle(Color.yellow)
                            .offset(y: -size * 0.355)
                            .rotationEffect(.degrees(angle - model.heading))
                    }

                    VStack(spacing: 0) {
                        Text("HEADING").font(.system(size: size * 0.034, weight: .bold, design: .rounded))
                            .tracking(1.3).foregroundStyle(.gray)
                        Text(model.headingLabel)
                            .font(.system(size: size * (isWatch ? 0.075 : 0.07), weight: .black, design: .rounded))
                            .minimumScaleFactor(0.65).lineLimit(1).foregroundStyle(.white)
                    }
                    .offset(y: -size * 0.235)

                    HStack(spacing: 0) {
                        metric(title: "WIND SPEED", value: model.windSpeed, size: size)
                        Spacer(minLength: 1)
                        metric(title: "GUSTS", value: model.gusts, size: size)
                    }
                    .padding(.horizontal, size * 0.14)
                    .offset(y: -size * 0.005)

                    VStack(spacing: 0) {
                        Text("WIND FROM").font(.system(size: size * 0.034, weight: .bold, design: .rounded))
                            .tracking(1).foregroundStyle(Color(red: 0.63, green: 0.69, blue: 0.77))
                        Text(model.windFromLabel)
                            .font(.system(size: size * 0.067, weight: .black, design: .rounded))
                            .lineLimit(1).minimumScaleFactor(0.65).foregroundStyle(.white)
                    }
                    .offset(y: size * 0.265)

                    TrianglePointer().fill(Color.red)
                        .frame(width: size * (isWatch ? 0.105 : 0.085), height: size * 0.28)
                        .offset(y: -size * 0.18)
                        .rotationEffect(.degrees(model.windFrom.map { $0 - model.heading } ?? 0))
                        .opacity(model.windFrom == nil ? 0 : 1)

                    Circle().fill(Color(red: 0.02, green: 0.04, blue: 0.07))
                        .frame(width: size * 0.048, height: size * 0.048)
                        .overlay(Circle().fill(.white).padding(size * 0.012))
                        .position(x: size / 2, y: size / 2)
                }
                .frame(width: size, height: size)
                .frame(maxWidth: .infinity)

                HStack {
                    Image("NFELogo").resizable().scaledToFit()
                        .frame(width: min(geo.size.width * (isWatch ? 0.34 : 0.30), isWatch ? 88 : 150), height: isWatch ? 24 : 42)
                    Spacer(minLength: 0)
                }
                .padding(.leading, 4)
                .padding(.top, 1)

                if !isWatch && !model.permissionMessage.isEmpty {
                    Text(model.permissionMessage).font(.caption2).foregroundStyle(.gray).frame(maxWidth: .infinity, alignment: .leading)
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
            .background(Color.black)
        }
        .background(Color.black.ignoresSafeArea())
        .task { model.start() }
    }

    @ViewBuilder
    private func metric(title: String, value: String, size: CGFloat) -> some View {
        VStack(spacing: 0) {
            Text(title).font(.system(size: size * (isWatch ? 0.031 : 0.028), weight: .bold, design: .rounded))
                .tracking(0.5).lineLimit(1).minimumScaleFactor(0.6).foregroundStyle(.white)
            Text(value).font(.system(size: size * (isWatch ? 0.105 : 0.09), weight: .black, design: .rounded))
                .lineLimit(1).minimumScaleFactor(0.65).foregroundStyle(.white)
            Text("mph").font(.system(size: size * 0.042, weight: .medium, design: .rounded)).foregroundStyle(.gray)
        }.frame(maxWidth: .infinity)
    }
}

struct TrianglePointer: Shape {
    func path(in rect: CGRect) -> Path {
        Path { p in
            p.move(to: CGPoint(x: rect.minX, y: rect.minY))
            p.addLine(to: CGPoint(x: rect.maxX, y: rect.minY))
            p.addLine(to: CGPoint(x: rect.midX, y: rect.maxY))
            p.closeSubpath()
        }
    }
}
