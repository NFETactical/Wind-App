import Foundation
import CoreLocation
import SwiftUI

@MainActor
final class CompassModel: NSObject, ObservableObject, CLLocationManagerDelegate {
    @Published var heading: Double = 0
    @Published var windFrom: Double?
    @Published var windSpeed = "—"
    @Published var gusts = "—"
    @Published var headingLabel = "N · 0°"
    @Published var windFromLabel = "—"
    @Published var permissionMessage = ""

    private let manager = CLLocationManager()
    private var lastWeatherFetch = Date.distantPast

    override init() {
        super.init()
        manager.delegate = self
        manager.headingFilter = 1
        manager.desiredAccuracy = kCLLocationAccuracyKilometer
    }

    func start() {
        manager.requestWhenInUseAuthorization()
        if CLLocationManager.headingAvailable() { manager.startUpdatingHeading() }
        manager.startUpdatingLocation()
    }

    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        if manager.authorizationStatus == .authorizedWhenInUse || manager.authorizationStatus == .authorizedAlways {
            manager.startUpdatingLocation()
        } else if manager.authorizationStatus == .denied || manager.authorizationStatus == .restricted {
            permissionMessage = "Enable location access to load local wind."
        }
    }

    func locationManager(_ manager: CLLocationManager, didUpdateHeading newHeading: CLHeading) {
        let value = newHeading.trueHeading >= 0 ? newHeading.trueHeading : newHeading.magneticHeading
        let normalized = (value + 360).truncatingRemainder(dividingBy: 360)
        withAnimation(.easeOut(duration: 0.18)) {
            heading = normalized
            headingLabel = "\(Self.point(normalized)) · \(Int(normalized.rounded()))°"
        }
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.last else { return }
        guard Date().timeIntervalSince(lastWeatherFetch) > 300 else { return }
        lastWeatherFetch = Date()
        Task { await fetchWeather(for: location) }
    }

    private func fetchWeather(for location: CLLocation) async {
        let lat = location.coordinate.latitude
        let lon = location.coordinate.longitude
        guard let url = URL(string: "https://api.open-meteo.com/v1/forecast?latitude=\(lat)&longitude=\(lon)&current=wind_speed_10m,wind_direction_10m,wind_gusts_10m&wind_speed_unit=mph") else { return }
        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            let response = try JSONDecoder().decode(OpenMeteoResponse.self, from: data)
            windSpeed = "\(Int(response.current.wind_speed_10m.rounded()))"
            gusts = "\(Int(response.current.wind_gusts_10m.rounded()))"
            windFrom = response.current.wind_direction_10m
            windFromLabel = "\(Self.point(response.current.wind_direction_10m)) · \(Int(response.current.wind_direction_10m.rounded()))°"
        } catch {
            permissionMessage = "Could not refresh weather. Showing the last available reading."
        }
    }

    static func point(_ degrees: Double) -> String {
        let points = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"]
        let normalized = (degrees.truncatingRemainder(dividingBy: 360) + 360).truncatingRemainder(dividingBy: 360)
        return points[Int((normalized / 45).rounded()) % 8]
    }
}

struct OpenMeteoResponse: Decodable {
    struct Current: Decodable {
        let wind_speed_10m: Double
        let wind_direction_10m: Double
        let wind_gusts_10m: Double
    }
    let current: Current
}
