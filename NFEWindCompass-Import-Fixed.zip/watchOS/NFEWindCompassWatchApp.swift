import SwiftUI

@main
struct NFEWindCompassWatchApp: App {
    var body: some Scene {
        WindowGroup {
            CompassView(isWatch: true)
                .preferredColorScheme(.dark)
        }
    }
}
