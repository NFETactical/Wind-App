# NFE Tactical Wind Compass — iOS + Apple Watch package

This ZIP now includes a root `manifest.json` for importers that request one, plus source code for both iOS and watchOS.

## Important about Xcode
Xcode's normal native app workflow does **not** require a root `manifest.json`. It expects an Xcode project (`.xcodeproj`) or Swift Package (`Package.swift`). The manifest included here is package metadata for an importer that specifically requests it; it does not replace the Xcode project.

## Files
- `manifest.json` — package metadata describing both iOS and watchOS targets
- `iOS/NFEWindCompassIOSApp.swift` — iPhone app entry point
- `watchOS/NFEWindCompassWatchApp.swift` — Apple Watch app entry point
- `Shared/CompassView.swift` — shared compass UI adapted to phone/watch screen size
- `Shared/CompassModel.swift` — heading/location and Open-Meteo weather logic
- `Shared/Assets.xcassets/NFELogo.imageset` — NFE Tactical logo

## Add to Xcode
1. On a Mac, open Xcode.
2. Create a new iOS App project and a new watchOS App project (or add a watch app target to the iOS project).
3. Add the shared Swift files and asset catalog to each appropriate target. Add only the matching `@main` entry-point file to each target.
4. In each target's Info settings, add `NSLocationWhenInUseUsageDescription` with the text in `Shared/InfoPlist-Location-Permission.json`.
5. Set iOS deployment target to iOS 17+ and watchOS to watchOS 10+.
6. Build and sign the iOS and watchOS targets before installing them.

## Functionality
- Black background, double white compass rings, yellow cardinal labels inside the dial
- Degree ticks every 10°, longer ticks every 30°
- Red triangular wind arrow and centered hub
- Heading, wind speed, gusts, and wind-from readouts
- NFE Tactical logo
- Device heading and location-based current weather from Open-Meteo

The app requires internet access and location permission. Weather is model-based data, not a physical wind sensor. This package is source code and is not yet a signed, installable app.


## App icons
The supplied NFE mark is included as a 1024 × 1024 PNG in two Xcode asset sets:
- `Shared/Assets.xcassets/AppIcon.appiconset` for the iOS app
- `Shared/Assets.xcassets/WatchAppIcon.appiconset` for the watchOS app

When configuring the targets in Xcode, select `AppIcon` as the iOS target's App Icon source and `WatchAppIcon` for the watchOS target if your Xcode version supports that asset-set format. Some Xcode/watchOS deployment combinations may require selecting or generating a watch-specific icon set in the target's asset catalog. This bundle is source/assets, not a signed Xcode project or installable app.
